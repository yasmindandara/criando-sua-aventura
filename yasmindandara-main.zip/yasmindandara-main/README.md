## Boas vindas ao meu perfil 🖤

Meu nome e Yasmin Dandara

- Estou estudando na Alura
- Estou me desenvolvendo na linguagem JavaScript
- Utilizo esse espaço para minha organização e compartilhamento dos meu projetos desenvolvidos

## Você pode entrar em contato comigo 📫

00001100888652sp@al.educacao.sp.gov.br

  


